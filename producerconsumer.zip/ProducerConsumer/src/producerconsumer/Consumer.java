package producerconsumer;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import producerconsumer.MyQueue;
import producerconsumer.ITStudent;

public class Consumer implements Runnable
{
    private MyQueue myQueue;
    
    public Consumer(MyQueue myQueue)
    { this.myQueue = myQueue; }
    
    public void run()
    {
        
        while (myQueue.Count <= 11)
        { 
            try {
                   myQueue.get();
                
                    FileInputStream fileInputStream = new FileInputStream(MyQueue.item);

                    JAXBContext jaxbContext = JAXBContext.newInstance(ITStudent.class);
                    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
                    ITStudent student = (ITStudent) unmarshaller.unmarshal(fileInputStream);

                    System.out.print(student);
                
            } catch (JAXBException ex) {
                Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}