/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package producerconsumer;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Nobandile Dlamini & Nomathamsanqa Jiyane
 */
@XmlRootElement
public class Student {

    String filename;
    String name;
    String surname;
    int id;
    
    ArrayList<String> courses;
    ArrayList<Integer> marks;
    
    public String getFilename()
    {
        return filename;
    }

    @XmlAttribute
    public void setFilename(String filename)
    {
        this.filename = filename;
    }

    public String getName() {
        return name;
    }

    @XmlElement
    public void setName(String name) {
         this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    @XmlElement
    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getId() {
        return id;
    }

    @XmlElement
    public void setId(int id) {
         this.id = id;
    }
    
      public ArrayList<String> getCourses()
    {
        return courses;
    }

    @XmlElement
    public void setCourses(ArrayList<String> courses)
    {
        this.courses = courses;
    }
    
      public ArrayList<Integer> getMarks()
    {
        return marks;
    }

    @XmlElement
    public void setMarks(ArrayList<Integer> marks)
    {
        this.marks = marks;
    }


}