package producerconsumer;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import producerconsumer.MyQueue;

public class Producer implements Runnable {
        private MyQueue myQueue;
                  
        public Producer(MyQueue myQueue) 
        { this.myQueue = myQueue; }
 
        public void run()
        {
            while (myQueue.Count <= 10)
            {                
                  File data = new File("STUDENT"+myQueue.Count+".xml");
                 
                try 
                {
                     FileOutputStream output = new FileOutputStream(data);
                     data = CreateData();
                } 
                catch (Exception ex) {
                    Logger.getLogger(Producer.class.getName()).log(Level.SEVERE, null, ex); }
                                
                //producer put items
                myQueue.put(data);  
           } 
        }

    private File CreateData() throws Exception{
        //generate student ID
        Random r =  new Random();
        int id = r.nextInt(100000000);
        //generate student name
        int index = new Random().nextInt(StudentData.names.size());
        String name = StudentData.names.get(index);
        //generate student name      
        int ind = new Random().nextInt(StudentData.surnames.size());
        String surname = StudentData.surnames.get(ind);
        
        
        ArrayList<String> course = new ArrayList<String>();
        ArrayList<Integer> mark = new ArrayList<Integer>();
        for(int j=1; j<6; j++)
        {   //generate student courses
            int i = new Random().nextInt(StudentData.course.size());
            String courses = StudentData.course.get(i);
            course.add(StudentData.course.get(i));
            
            //generate student marks
            int k = new Random().nextInt(100);
            mark.add(k);   
        }


        Student c = new Student();
        c.setSurname(name);
        c.setFilename("STUDENT"+(myQueue.Count)+".xml");
        c.setId(id);
        c.setCourses(course);
        c.setMarks(mark);
        c.setName(surname);
        
        JAXBContext jaxbContext = JAXBContext.newInstance(Student.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      
        File file = new File("STUDENT"+(myQueue.Count)+".xml");
        jaxbMarshaller.marshal(c, file);
        //StringWriter sw = new StringWriter();
        //jaxbMarshaller.marshal(c, sw);
        //String xmlString = sw.toString();
        //System.out.println(xmlString);
        
      
      //String xmlString = "File "+"STUDENT"+(myQueue.Count)+".xml"+" "+"Created";
      //System.out.println();
     // System.out.println(xmlString);
       
      return file;
    }
}
