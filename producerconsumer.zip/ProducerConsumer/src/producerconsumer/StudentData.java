/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package producerconsumer;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Nomathamsanqa Jiyane
 */
 public class StudentData 
 {
        static String[] randnames = {"Tema", "Banele", "Prudence", "Asakhe", "Velile","Jekwa", "Jane", "Jack", 
                                     "Mlondi", "Lethukuthula","Thabo","Temaswati","Brandon", "Thandeka", "Mlimi", 
                                     "Sakhile", "Mary", "Sicelo", "Lucky", "Valencia", "Melisa", "Ntombi", "Ntombizodwa", 
                                     "Ndoda", "Pholile", "Nakekelo","Njabulo", "Nomfundo", "Mbuso", "Tamicah", "Shenaida",
                                     "Nobuhle", "Cherane", "Nomthetho", "Jordan", "Micheal","Vinolia", "Charlotte", "Simiso", 
                                     "Ndumiso", "Lindokuhle", "Benjamin", "Thembela", "Maxwell", "Brian","Fanelo", "Ncamisile", 
                                     "Refilwe", "Vuyokazi", "Gugulethu", "Thabang", "Sifiso", "Zanokuhle", "Sandile", "Inathi",
                                     "Ncamiso", "Bongiwe", "Nobandile", "Abongwe", "Kgotso", "Lungelo"};
        static List<String> names = Arrays.asList(randnames);   
        
        static String[] randsurnames = {"Dlamini","Masilela", "Nxumalo", "Mamba", "Mnguni", "Jiyane", "Tsabedze", "Dube", 
                                        "Van Vuuren", "Mkhatshwa", "Maseko", "Ngcamphalala","Vilakati", "Brown", "Smith", "First", 
                                        "Dlamini", "Vilane", "Tawe", "Haines", "Motsa", "Sibandze", "McKenzie", "Lukhele", "Jackson", 
                                        "Biyela", "Ward","Sibeko", "Nanisca", "Nunes", "Muir", "Shongwe", "Gamedze", "Shabangu", "Khumalo",
                                        "Lerumo", "Zishwili", "Lubisi", "Sephume", "Mfana", "Zwane", "Lechela"};
        static List<String> surnames = Arrays.asList(randsurnames);
        
        static String[] randcourses = {"Course1","Course2","Course3","Course4", "Course5", "Course6", "Course7"};
        static List<String> course = Arrays.asList(randcourses);
        
    }
