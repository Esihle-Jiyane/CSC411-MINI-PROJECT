/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package producerconsumer;
import producerconsumer.MyQueue;

public class ProducerConsumer 
{
    public static void main(String[] args) throws InterruptedException
    {
       //creating buffer queue
       MyQueue myQueue = new MyQueue();
             
        Producer producer = new Producer(myQueue);
        Consumer consumer = new Consumer(myQueue);
        
        //starting producer thread
        Thread producerThread = new Thread(producer);
        producerThread.start();
        
        //starting consumer thread
        Thread consumerThread = new Thread(consumer);
        consumerThread.start();
    }

}
