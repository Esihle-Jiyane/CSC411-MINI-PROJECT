/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package producerconsumer;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Nomathamsanqa Jiyane
 */

@XmlRootElement(name = "student")
@XmlAccessorType(XmlAccessType.FIELD)
public class ITStudent {
       
        @XmlElement(name = "name")
	private String name;
	@XmlElement(name = "id")
	private Integer id;
	@XmlElement(name = "surname")
	private String surname;
	@XmlElement(name = "courses")
	private List<String> courses;
        @XmlElement(name = "marks")
	private List<Integer> marks;

        @Override
	public String toString() {
         
            String result = null;
            int j = 0, temp = 0, average = 0;
            
            for (int i=0; i<marks.size(); i++)
            {    
                j = i+1;
                temp = temp + marks.get(i);
                                
                //System.out.print("Addition = " + temp);
            }
                average = (temp/j);
                
                if (average > 50)
                { result = "PASS"; }
                else 
                {result = "FAIL"; }
                  
            return " StudentId = " + id 
                     + "\n Name = " + name + " " + surname 
                     + "\n Courses = " + courses 
                     + "\n Marks = " + marks
                     + "\n" + " Average: " + average + "%"
                     + " "+ result +"\n"+"\n";
	}
}
