
package producerconsumer;
import java.io.File;
import java.util.concurrent.Semaphore;

public class MyQueue {
    static File item;
    int Count=1;
               
    //semaphoreConsumer initiated
    private Semaphore semaphoreConsumer = new Semaphore(0);
    private Semaphore semaphoreProducer = new Semaphore(1);
        
     public void get() {
        try {
              //acquire permit before consuming 
                semaphoreConsumer.acquire();            
            }
        catch (InterruptedException e)
        { System.out.println("InterruptedException caught");}
        
       //Consumer consuming an item
       System.out.println(item);
                          
       //Release semaphore to notify producer
       semaphoreProducer.release();
    }
    
    //Placing an item into the buffer
    public void put (File item)
    {
        try {
                //acquire permit before producing 
                semaphoreProducer.acquire();
            } 
        catch (InterruptedException e)
        { System.out.println("InterruptedException caught");}
        
    //Producer producing an item
        this.item = item;
        //System.out.println("Producer produced Student: " + item);
        Count++; 
        
        semaphoreConsumer.release();
    }
}

